<?php

namespace App\Http\Controllers;

use App\Mail\myemail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
    public function send(Request $request){
        Mail::to('cantact@modernkasbokar.ir')->send(new myemail($request->name, $request->phone_number,$request->job));
//        return redirect()->route('')->with('success', 'ثبت نام شما با موفقیت ثبت شد');
        return redirect()->route('success');
    }

    public function success()
    {
        return view('success');
    }
}
